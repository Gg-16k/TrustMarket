TRUST MARKET — PREMIUM FULL-STACK-READY VERSION

What is included:
- Premium mobile-first marketplace UI.
- Home hero uses the supplied marketplace visuals: modern home/interior + premium car + furniture. ETCARE is intentionally excluded from the Home Hero.
- Focused category experience: clicking House & Land, Cars, Furniture & Electronics, Jobs, or Professional Services opens only that category; choosing Buyer/Seller (or the relevant role) replaces the choice screen with that category's specific form.
- ETCARE products with photos, benefits, how-to-use, prices, quantity, cart, Buy Now and social share icons.
- Five-product ETCARE bundle: 5,495 ETB -> 10% discount -> 4,945.50 ETB.
- Business Opportunity is separate from ETCARE product shopping: Gold 17,899 ETB; Ziva 13,989 ETB; Glow 9,989 ETB.
- Payment flow is explicit: choose method -> scan QR -> verify recipient -> pay outside Trust Market -> submit receipt -> Pending -> admin verification -> Approved/Rejected.
- PIN/password/OTP are never requested.
- Personal payment account numbers are not written as plain text in the frontend. The UI uses masked references and QR images.
- Buyer/seller personal phone numbers are private. Public approved listings omit phone/contact fields.
- Server API routes for orders, listings, admin login, moderation, and health checks.
- Neon PostgreSQL schema and automatic table creation.
- HttpOnly, Secure, SameSite=Strict admin session cookie using HMAC with SESSION_SECRET.
- Admin dashboard at /admin.html for order/payment receipt verification and listing approval/rejection.
- Approved listings are displayed publicly only after admin approval.
- Receipt images are compressed in the browser before submission and rejected when too large.
- Facebook, WhatsApp, Telegram and native share icons.
- Open Graph/Twitter social preview metadata.
- robots.txt, sitemap.xml, 404.html, Vercel security headers.

LIVE SETUP REQUIRED BEFORE CLAIMING SERVER-SIDE FUNCTIONS ARE ACTIVE:
1. Deploy this project to Vercel.
2. Connect a Neon Postgres database (or provide DATABASE_URL).
3. Add these Vercel Environment Variables for Production:
   DATABASE_URL
   ADMIN_EMAIL
   ADMIN_PASSWORD
   SESSION_SECRET
4. Open /admin.html and sign in with the configured admin credentials.
5. Submit one test order and one test listing, then approve them from the dashboard.

Important:
No website can honestly make a real bank/payment transaction or server-side admin moderation secure without a backend service and secret environment variables. This package contains the real backend structure, but those external credentials must be configured in Vercel. It does not fake automatic payment verification.
