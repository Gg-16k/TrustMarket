import { db, ensureTables } from './_db.js';
export default async function handler(req,res){
 try{const sql=db();await ensureTables(sql);return res.status(200).json({ok:true,database:true});}
 catch(err){return res.status(503).json({ok:false,database:false,error:err.message||'Database not configured'});}
}
