import { db, ensureTables, reference } from './_db.js';

export const config={api:{bodyParser:{sizeLimit:'5mb'}}};

export default async function handler(req,res){
  try{
    const sql=db(); await ensureTables(sql);
    if(req.method==='POST'){
      const body=req.body||{};
      const category=String(body.category||'').trim();
      const categoryTitle=String(body.categoryTitle||'').trim();
      const role=String(body.role||'').trim();
      const data=body.data&&typeof body.data==='object'?body.data:{};
      const photos=Array.isArray(body.photos)?body.photos.slice(0,6):[];
      if(!category||!categoryTitle||!['seller','buyer'].includes(role)||!data.name||!data.phone) return res.status(400).json({error:'Please complete the required contact details.'});
      for(const photo of photos){if(typeof photo!=='string'||!photo.startsWith('data:image/')||photo.length>1900000) return res.status(400).json({error:'One of the listing images is invalid or too large.'});}
      const ref=reference('TM-LST');
      await sql`INSERT INTO tm_listings(reference,category,category_title,role,payload,photos) VALUES(${ref},${category},${categoryTitle},${role},${JSON.stringify(data)},${JSON.stringify(photos)})`;
      return res.status(201).json({ok:true,reference:ref,status:'pending'});
    }
    if(req.method==='GET'){
      const rows=await sql`SELECT id,reference,category,category_title,role,payload,photos,created_at FROM tm_listings WHERE status='approved' ORDER BY created_at DESC LIMIT 100`;
      const safe=rows.map(r=>{const p={...r.payload};delete p.phone;delete p.contact;return {...r,payload:p}});
      return res.status(200).json({items:safe});
    }
    return res.status(405).json({error:'Method not allowed'});
  }catch(err){console.error(err);return res.status(503).json({error:err.message||'Listing service is temporarily unavailable.'});}
}
