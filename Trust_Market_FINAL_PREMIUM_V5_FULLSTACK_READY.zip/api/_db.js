import { neon } from '@neondatabase/serverless';

export function db(){
  const url=process.env.DATABASE_URL;
  if(!url) throw new Error('DATABASE_URL is not configured. Connect a Neon database in Vercel first.');
  return neon(url);
}

export async function ensureTables(sql){
  await sql`CREATE TABLE IF NOT EXISTS tm_orders (
    id BIGSERIAL PRIMARY KEY,
    reference TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    contact TEXT,
    payment_method TEXT NOT NULL,
    details TEXT NOT NULL,
    receipt_data TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
    admin_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE TABLE IF NOT EXISTS tm_listings (
    id BIGSERIAL PRIMARY KEY,
    reference TEXT UNIQUE NOT NULL,
    category TEXT NOT NULL,
    category_title TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('seller','buyer')),
    payload JSONB NOT NULL,
    photos JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
    admin_note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
}

export function reference(prefix){
  const now=Date.now().toString(36).toUpperCase();
  const rand=Math.random().toString(36).slice(2,7).toUpperCase();
  return `${prefix}-${now}-${rand}`;
}
