import { db, ensureTables } from '../_db.js';
import { verify } from './auth.js';
export const config={api:{bodyParser:{sizeLimit:'1mb'}}};
export default async function handler(req,res){
 if(!verify(req))return res.status(401).json({error:'Admin authentication required.'});
 if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});
 try{
  const {type,id,status,note}=req.body||{};
  if(!['orders','listings'].includes(type)||!Number.isInteger(Number(id))||!['pending','approved','rejected'].includes(status))return res.status(400).json({error:'Invalid update.'});
  const sql=db();await ensureTables(sql);const num=Number(id);
  if(type==='orders')await sql`UPDATE tm_orders SET status=${status},admin_note=${String(note||'')},updated_at=NOW() WHERE id=${num}`;
  else await sql`UPDATE tm_listings SET status=${status},admin_note=${String(note||'')},updated_at=NOW() WHERE id=${num}`;
  return res.status(200).json({ok:true});
 }catch(err){return res.status(503).json({error:err.message||'Update failed.'});}
}
