import crypto from 'node:crypto';

function token(){
  const payload=Buffer.from(JSON.stringify({sub:'admin',exp:Date.now()+8*60*60*1000})).toString('base64url');
  const secret=process.env.SESSION_SECRET;
  if(!secret) throw new Error('SESSION_SECRET is not configured.');
  const sig=crypto.createHmac('sha256',secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}
export function verify(req){
  const raw=(req.headers.cookie||'').match(/(?:^|;\s*)tm_admin=([^;]+)/)?.[1];
  const secret=process.env.SESSION_SECRET;
  if(!raw||!secret)return false;
  const [payload,sig]=raw.split('.');
  if(!payload||!sig)return false;
  const expected=crypto.createHmac('sha256',secret).update(payload).digest('base64url');
  if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return false;
  try{return JSON.parse(Buffer.from(payload,'base64url').toString()).exp>Date.now()}catch{return false}
}
export default async function handler(req,res){
  if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});
  const {email,password}=req.body||{};
  if(!process.env.ADMIN_EMAIL||!process.env.ADMIN_PASSWORD||!process.env.SESSION_SECRET)return res.status(503).json({error:'Admin authentication is not configured yet. Add ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET in Vercel environment variables.'});
  if(String(email||'').trim()!==process.env.ADMIN_EMAIL||String(password||'')!==process.env.ADMIN_PASSWORD)return res.status(401).json({error:'Incorrect admin credentials.'});
  const t=token();res.setHeader('Set-Cookie',`tm_admin=${t}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`);return res.status(200).json({ok:true});
}
