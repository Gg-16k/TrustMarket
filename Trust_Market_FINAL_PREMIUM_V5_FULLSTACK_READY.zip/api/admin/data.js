import { db, ensureTables } from '../_db.js';
import { verify } from './auth.js';
export default async function handler(req,res){
  if(!verify(req))return res.status(401).json({error:'Admin authentication required.'});
  try{
    const sql=db();await ensureTables(sql);
    const orders=await sql`SELECT id,reference,name,phone,contact,payment_method,details,receipt_data,status,admin_note,created_at,updated_at FROM tm_orders ORDER BY created_at DESC LIMIT 200`;
    const listings=await sql`SELECT id,reference,category,category_title,role,payload,photos,status,admin_note,created_at,updated_at FROM tm_listings ORDER BY created_at DESC LIMIT 200`;
    return res.status(200).json({orders,listings});
  }catch(err){return res.status(503).json({error:err.message||'Admin data unavailable.'});}
}
