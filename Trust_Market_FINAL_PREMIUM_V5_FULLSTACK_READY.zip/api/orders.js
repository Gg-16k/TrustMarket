import { db, ensureTables, reference } from './_db.js';

export const config={api:{bodyParser:{sizeLimit:'5mb'}}};

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  try{
    const body=req.body||{};
    const name=String(body.name||'').trim();
    const phone=String(body.phone||'').trim();
    const contact=String(body.contact||'').trim();
    const method=String(body.method||'').trim();
    const details=String(body.details||'').trim();
    const receipt=typeof body.receipt==='string'?body.receipt:null;
    if(!name||!phone||!method||!details) return res.status(400).json({error:'Please complete name, phone, payment method and order details.'});
    if(receipt && (!receipt.startsWith('data:image/') || receipt.length>3300000)) return res.status(400).json({error:'Receipt image is invalid or too large. Please use a clear image under about 2.2 MB.'});
    const sql=db(); await ensureTables(sql);
    const ref=reference('TM-ORD');
    await sql`INSERT INTO tm_orders(reference,name,phone,contact,payment_method,details,receipt_data) VALUES(${ref},${name},${phone},${contact||null},${method},${details},${receipt})`;
    return res.status(201).json({ok:true,reference:ref,status:'pending'});
  }catch(err){
    console.error(err); return res.status(503).json({error:err.message||'Order service is temporarily unavailable.'});
  }
}
