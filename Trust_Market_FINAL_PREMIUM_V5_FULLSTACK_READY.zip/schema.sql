-- Trust Market database schema. The app can also create these tables automatically.
-- Run this once in your Neon SQL editor if you prefer manual setup.
CREATE TABLE IF NOT EXISTS tm_orders (
  id BIGSERIAL PRIMARY KEY,
  reference TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  contact TEXT,
  payment_method TEXT NOT NULL,
  details TEXT NOT NULL,
  receipt_data TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  admin_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS tm_listings (
  id BIGSERIAL PRIMARY KEY,
  reference TEXT UNIQUE NOT NULL,
  category TEXT NOT NULL,
  category_title TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('seller','buyer')),
  payload JSONB NOT NULL,
  photos JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  admin_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
